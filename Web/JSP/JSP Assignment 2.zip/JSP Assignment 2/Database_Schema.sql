CREATE DATABASE userInformation;
USE userInformation;
CREATE TABLE user (firstname varchar(200),lastname varchar(200),username varchar(200),email varchar(200),password 
varchar(200));
DROP TABLE user;